# -*- coding: utf-8 -*-
"""
Created on Wed Dec  4 17:01:07 2019

@author: anshuman.neog
"""
import RF_model_parameters as mlflow_json
import mlflow

def log_params():
    model_name = list(mlflow_json.classification_params.keys())[0]
    params = mlflow_json.classification_params[model_name]['Final_Params']    
    mlflow.log_param('Model Name', model_name)
    for key in params.keys():
        mlflow.log_param(key, params[key])

def log_metrics(dictionary):
    for key in dictionary.keys():
        mlflow.log_metric(key, dictionary[key])
