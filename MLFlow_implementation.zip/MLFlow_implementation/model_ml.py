# -*- coding: utf-8 -*-
"""
Created on Wed Dec  4 15:46:07 2019

@author: anshuman.neog
"""
import RF_model_parameters as mlflow_json
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import RandomForestRegressor

class Model_ML:
    

    model_name = list(mlflow_json.classification_params.keys())[0]
    
    
    def set_model(self, model_type):
        params = mlflow_json.classification_params[self.model_name]['Final_Params']
        if model_type == 'Regression':
            model = RandomForestRegressor(**params)
        else:
            model = RandomForestClassifier(**params)
        return model
    
    def fit_model(self, model, train_df, y_train):
        model.fit(train_df, y_train)
        return model
    
    def model_predict(self, model, df):
        y_predict_prob = model.predict_proba(df)
        return y_predict_prob
    
        
        
    def modelling_main(self, model_type, train, y, test):
        model_set = self.set_model(model_type)
        model_fit = self.fit_model(model_set,train, y)
        (test_predicted, train_predicted) = self.model_predict(model_fit, test, train)
        return test_predicted, train_predicted, model_fit

# methods - 3
# 1. Set
# 2. fit
# 3. predict