# -*- coding: utf-8 -*-
"""
Created on Tue Dec  3 16:57:05 2019

@author: anshuman.neog
"""

def optimal_thres(Actuals, Predicted_Proba):
    import numpy as np
    import pandas as pd
    from sklearn.metrics import roc_auc_score
    from sklearn.metrics import roc_curve
    optimal_threshold_dict = {}
#    auc_score_test = roc_auc_score(Actuals, Predicted_Proba)
    ns_probs = [0 for _ in range(len(Actuals))]
    ns_fpr, ns_tpr, _ = roc_curve(Actuals, ns_probs)
    
    rf_fpr, rf_tpr, _ = roc_curve(Actuals, 
                                  Predicted_Proba)
    
    i = np.arange(len(rf_tpr)) 
    roc = pd.DataFrame({'fpr' : pd.Series(rf_fpr, index=i),
                        'tpr' : pd.Series(rf_tpr, index = i), 
    '1-fpr' : pd.Series(1-rf_fpr, index = i), 'tf' : pd.Series(rf_tpr - (1-rf_fpr), index = i), 
    'thresholds' : pd.Series(_, index = i)})
    optimal_threshold_df = roc.ix[(roc.tf-0).abs().argsort()[:1]]
    optimal_threshold = optimal_threshold_df.thresholds.values[0]
    optimal_threshold_dict['optimal_threshold'] = optimal_threshold
    optimal_threshold_dict['ns_fpr'] = ns_fpr
    optimal_threshold_dict['ns_tpr'] = ns_tpr
    optimal_threshold_dict['rf_fpr'] = rf_fpr
    optimal_threshold_dict['rf_tpr'] = rf_tpr
    return optimal_threshold_dict


def Predicted_1_0(df, Predicted_Proba, optimal_threshold):
    
    df['Result'] = [1 if p >= optimal_threshold else 0 for p in df[Predicted_Proba]]
    df['TP'] = [1 if x == 1 and y == 1.0 else 0 for x, y in zip(df['Result'], df['Actual'])]
    df['FP'] = [1 if x == 1 and y == 0.0 else 0 for x, y in zip(df['Result'], df['Actual'])]
    df['TN'] = [1 if x == 0 and y == 0.0 else 0 for x, y in zip(df['Result'], df['Actual'])]
    df['FN'] = [1 if x == 0 and y == 1.0 else 0 for x, y in zip(df['Result'], df['Actual'])]
    
#    Precision = sum(df['TP'])/sum((df['TP'] + df['FP']))
#    Recall = sum(df['TP'])/sum((df['TP'] + df['FN']))
    
    return df

