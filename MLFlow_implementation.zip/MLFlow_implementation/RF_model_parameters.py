# -*- coding: utf-8 -*-
"""
Created on Tue Dec  3 13:18:21 2019

@author: anshuman.neog
"""

classification_params = {
    "Random Forest": {
        "Final_Params": {"n_estimators": 1000,
                         "max_depth": 3,
                         "min_samples_split": 2,
                         "max_features": 0.7,
                         "min_samples_leaf": 1,
                         "random_state": 33,
                         "n_jobs": 40,
                         "oob_score": True,
                         "class_weight": 'balanced'
                         },
        "Grid_Search_Params": {
            "Variable_params": {"n_estimators": [700, 1000],
                                "max_depth": [3, 5]

                                },
            "Fixed_params": {
                "max_features": 0.7,
                "min_samples_split": 3,
                "min_samples_leaf": 1,
                "random_state": 33,
                "n_jobs": 4
            }
        }
    }
}


